def gets!(text="") #"gets" equivalent, but including print, as in Python
  printf(text)
  return gets
end
